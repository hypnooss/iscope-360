Platform

&#x20;├── Infra (Kafka, DB)

&#x20;├── Orchestration  ← NOVO

&#x20;├── Templates      ← NOVO

&#x20;└── Processing



Agent

&#x20;├── Execution Engine

&#x20;├── Modules

&#x20;└── Sandbox



Task

&#x20;└── Contrato entre eles

